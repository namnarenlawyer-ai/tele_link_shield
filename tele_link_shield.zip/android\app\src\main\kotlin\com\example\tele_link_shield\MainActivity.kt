package com.example.tele_link_shield

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
