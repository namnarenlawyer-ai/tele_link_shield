// Copyright 2020 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#import <TargetConditionals.h>

#if TARGET_OS_OSX
#import <FlutterMacOS/FlutterMacOS.h>
#else
#import <Flutter/Flutter.h>
#endif

#import <AuthenticationServices/AuthenticationServices.h>
#import <Foundation/Foundation.h>
#if __has_include(<firebase_core/FLTFirebasePlugin.h>)
#import <firebase_core/FLTFirebasePlugin.h>
#else
#import <FLTFirebasePlugin.h>
#endif
#import "firebase_auth_messages.g.h"

#if !TARGET_OS_OSX
@protocol FlutterSceneLifeCycleDelegate;
#endif

@interface FLTFirebaseAuthPlugin
    : FLTFirebasePlugin <FlutterPlugin,
                         FirebaseAuthHostApi,
                         FirebaseAuthUserHostApi,
                         MultiFactorUserHostApi,
                         MultiFactoResolverHostApi,
                         MultiFactorTotpHostApi,
                         MultiFactorTotpSecretHostApi,
                         ASAuthorizationControllerDelegate,
                         ASAuthorizationControllerPresentationContextProviding
#if !TARGET_OS_OSX
#if __has_include(<Flutter/FlutterSceneLifeCycleDelegate.h>) || \
    defined(FlutterSceneLifeCycleDelegate)
                         ,
                         FlutterSceneLifeCycleDelegate
#endif
#endif
                         >

+ (FlutterError *)convertToFlutterError:(NSError *)error;
@end
